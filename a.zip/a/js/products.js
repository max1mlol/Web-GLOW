// Гол зорилго: api.js-ээс шүүгдсэн өгөгдлийг аваад, components.js-ээр зуруулаад дэлгэцэнд гаргадаг

// Бусад файл дээр бэлдсэн функцүүдээ энд ашиглахын тулд дуудаж байна
import { fetchProducts, filterProducts, sortProducts } from './api.js';
import { ProductCard, EmptyState, LoadingSpinner, ActiveFilterBadge } from './components.js';


// Browser-ийн санах ойноос "savedProducts" гэсэн түлхүүр үгээр өмнө нь хадгалсан барааны ID-нуудыг уншиж авна. Хэрэв хоосон бол [] буцаана
const savedProductIds = new Set(
  JSON.parse(localStorage.getItem('savedProducts') || '[]')
); // Set -> duplicate утгыг хасна

const grid = document.getElementById('products-grid');
const countEl = document.querySelector('.products-count');
const sortSelect = document.getElementById('sort-select');
const searchInput = document.getElementById('search-input');
const searchForm = document.querySelector('.search-box');

// getUrlParams — URL-ийн query параметрүүдийг объект болгон авна
// Жишээ URL: products.html?category=Серум&skinType=Хуурай+арьс&sort=rating
// Буцаах: { category: "Серум", skinType: "Хуурай арьс", sort: "rating", ... }
function getUrlParams() {
  // Вэбсайтын хаяг дээрх "?category=Serum" гэх мэт мэдээллийг уншина
  const params = new URLSearchParams(window.location.search);

  return {
    category : params.get('category')  || '',
    skinType : params.get('skinType')  || '',
    q        : params.get('q')         || '',
    minPrice : params.get('minPrice')  || '',
    maxPrice : params.get('maxPrice')  || '',
    sort     : params.get('sort')      || 'featured',
  };
}

// Хэрэглэгч шүүлтүүр ашиглах үед URL-ийг шинэчилнэ (хуудсыг дахин ачааллахгүйгээр)
function updateUrl(params) {
  const query = new URLSearchParams();

  // Хоосон утгыг URL-д нэмэхгүй
  Object.entries(params).forEach(([key, value]) => {
    if (value) query.set(key, value);
  });

  const newUrl = window.location.pathname +
    (query.toString() ? '?' + query.toString() : '');

  // history.pushState — browser Back/Forward товч ажиллана
  history.pushState({}, '', newUrl);
}

// updateActiveFilters — sidebar-ийн холбоосуудыг тохируулах
// Одоогийн URL параметртэй тохирох холбоосыг "active" болгоно.
function updateActiveFilters(params) {
  // Ангиллын холбоосууд
  document.querySelectorAll('.filter-category-link').forEach(link => {
    const isActive = link.dataset.category === params.category;
    link.classList.toggle('active', isActive);
  });

  // Sort select
  if (sortSelect && params.sort) {
    sortSelect.value = params.sort;
  }

  // Search input
  if (searchInput && params.q) {
    searchInput.value = params.q;
  }
}

// updatePageTitle — хуудасны гарчиг + тоолуурыг шинэчлэнэ
function updatePageTitle(params, count) {
  const h1 = document.querySelector('.page-header h1');
  if (h1) {
    h1.textContent = params.category
      ? params.category
      : 'Бүх бүтээгдэхүүн';
  }

  // Тоолуур
  if (countEl) {
    countEl.innerHTML = `<strong>${count}</strong> бүтээгдэхүүн харагдаж байна`;
  }
}

// идэвхтэй шүүлтүүрүүдийг харуулна
function renderActiveFilterBadges(params) {
  let container = document.getElementById('active-filters-bar');

  // Контейнер байхгүй бол үүсгэнэ
  if (!container) {
    container = document.createElement('div');
    container.id = 'active-filters-bar';
    container.className = 'active-filters-bar';

    const toolbar = document.querySelector('.products-toolbar');
    if (toolbar) {
      toolbar.insertAdjacentElement('afterend', container);
    }
  }

  container.innerHTML = '';

  // Идэвхтэй шүүлтүүр бүрт badge нэмнэ
  const filterMap = {
    category : params.category,
    skinType : params.skinType,
    q        : params.q ? `"${params.q}"` : '',
    minPrice : params.minPrice ? `$${params.minPrice}+` : '',
    maxPrice : params.maxPrice ? `$${params.maxPrice}-` : '',
  };

  let hasActive = false;

  // object -> array
  Object.entries(filterMap).forEach(([key, label]) => {
    /*

    key нь "category", value нь "Serum" гэх мэтээр орж ирнэ
    [
      ["category", "Serum"],
      ["price", 50]
    ]

    */
    if (!label) return;
    hasActive = true;

    const badge = ActiveFilterBadge(label, () => {
      // Тухайн шүүлтүүрийг URL-аас хасаж дахин render хийнэ
      const newParams = getUrlParams();
      newParams[key] = '';

      // minPrice + maxPrice-г хамтад нь хэрэглэсэн бол хоёуланг нь цэвэрлэнэ
      if (key === 'minPrice') newParams.maxPrice = '';
      if (key === 'maxPrice') newParams.minPrice = '';

      updateUrl(newParams);
      renderAll(newParams);
    });

    container.appendChild(badge);
  });

  // Бүх шүүлтүүр хасах товч
  if (hasActive) {
    const clearBtn = document.createElement('button');
    clearBtn.className = 'clear-filters-btn';
    clearBtn.textContent = 'Бүгдийг арилгах';
    clearBtn.addEventListener('click', () => {
      const empty = { category: '', skinType: '', q: '', minPrice: '', maxPrice: '', sort: params.sort };
      updateUrl(empty);
      renderAll(empty);
    });
    container.appendChild(clearBtn);
  }
}


// renderProducts — grid дэх карточнуудыг зурна
// Аргументууд:
// products — Product объектуудын массив (шүүгдсэн + эрэмбэлэгдсэн)
function renderProducts(products) {
  grid.innerHTML = '';

  if (products.length === 0) {
    grid.appendChild(EmptyState());
    return;
  }

  // product бүрийг ProductCard компонентоор үүсгэнэ
  products.forEach(product => {
    const card = ProductCard(product, {
      savedIds: savedProductIds,

      // Хадгалах товч дарахад localStorage-г шинэчлэнэ
      onSaveToggle: (id, isSaved) => {
        localStorage.setItem(
          'savedProducts',
          JSON.stringify([...savedProductIds])
        );
        console.log(`Бүтээгдэхүүн #${id} — ${isSaved ? 'хадгалсан' : 'хасагдсан'}`);
      }
    });

    grid.appendChild(card);
  });
}

// renderAll — бүх render үйлдлийг нэгтгэсэн функц
// Sort, Search, Badge, ProductGrid зэргийг цэгцтэй дуудна.
function renderAll(params) {
  // Sidebar-ийн active байдлыг тохируулах
  updateActiveFilters(params);

  // Шүүлт хийх
  const filtered = filterProducts(params);

  // Эрэмбэлэх
  const sorted = sortProducts(filtered, params.sort);

  // Гарчиг + тоолуур
  updatePageTitle(params, sorted.length);

  // Идэвхтэй шүүлтүүрийн badge-ууд
  renderActiveFilterBadges(params);

  // Карточнуудыг зурах
  renderProducts(sorted);
}

// init — хуудас ачааллахад нэг удаа дуудагдана
async function init() {
  grid.innerHTML = '';
  grid.appendChild(LoadingSpinner()); // Өгөгдөл татаж байх үед Loader үзүүлнэ

  await fetchProducts(); // api.js-ээр дамжуулан интернетээс дата татна (нэг удаа)

  const params = getUrlParams(); // Одоогийн URL дээрх шүүлтүүрийг авна

  // Бүх UI-г зурна
  renderAll(params);
}

// Sort select — сонголт өөрчлөгдөхөд
if (sortSelect) {
  sortSelect.addEventListener('change', () => {
    const params = getUrlParams();
    params.sort = sortSelect.value;
    updateUrl(params);
    renderAll(params);
  });
}

// Search form — хайх товч дарахад
if (searchForm) {
  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();  // Хуудас дахин ачааллахыг болиулна

    const params = getUrlParams();
    params.q = searchInput ? searchInput.value.trim() : '';
    params.sort  = sortSelect  ? sortSelect.value : 'featured';

    updateUrl(params);
    renderAll(params);
  });
}

// Browser Back / Forward товч дэмжих
// URL өөрчлөгдөхөд шинэ параметрүүдийг уншиж дахин render хийнэ
window.addEventListener('popstate', () => {
  const params = getUrlParams();
  renderAll(params);
});


// Хуудас ачааллах
init();