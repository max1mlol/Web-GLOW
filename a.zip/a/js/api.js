// JSONBin.io дээр байрлуулсан өгөгдлийн URL
const JSONBIN_URL = 'https://api.jsonbin.io/v3/b/69d0ddeeaaba882197c360de';

// Интернетээс ирсэн raw data-г эмх цэгцтэй объект болгож хувиргана
class Product {
  constructor({ id, name, category, skinType, price, originalPrice,
                rating, reviewCount, image, imageAlt, badge, description }) {
    this.id            = id;
    this.name          = name;
    this.category      = category;
    this.skinType      = skinType;
    this.price         = price;
    this.originalPrice = originalPrice; // null байж болно
    this.rating        = rating;
    this.reviewCount   = reviewCount;
    this.image         = image;
    this.imageAlt      = imageAlt;
    this.badge         = badge; // null байж болно
    this.description   = description;
  }

  // Хуучин үнэ байгаа эсэхийг шалгаж хямдралтай эсэхийг тогтооно
  isOnSale() {
    return this.originalPrice !== null && this.originalPrice > this.price;
  }

  getPriceHTML() {
    // Үнийг HTML хэлбэрээр бэлдэх
    if (this.isOnSale()) {
      return `$${this.price} <span class="product-price-original">$${this.originalPrice}</span>`;
    }
    return `$${this.price}`;
  }
}

let productTable = []; // fetch хийж татсан өгөгдлийг хадгалах хүснэгт


// JSONBin.io руу хандаж 9 ширхэг барааны мэдээллийг татаж авна
async function fetchProducts() {
  if (productTable.length > 0) {
    return productTable; // Хэрэв өмнө нь татсан бол дахин татахгүй (cache)
  }

  try {
    const response = await fetch(JSONBIN_URL);

    if (!response.ok) {
      throw new Error(`Серверийн алдаа: ${response.status}`);
    }

    const data = await response.json(); // Ирсэн мэдээллийг JS объект болгоно

    // JSONBin-ийн хариу дотроос "record" массивыг авна
    const rawList = data.record;

    // "Product" классын объект болгож хувирган productTable-д хадгална
    productTable = rawList.map(item => new Product(item));

    console.log(`${productTable.length} бүтээгдэхүүн татлаа.`);
    return productTable;

  } catch (error) {
    console.error('Өгөгдөл татахад алдаа гарлаа:', error.message);
    return [];
  }
}

//Вэбсайтын URL дээрх category=Серум гэх мэт мэдээллийг авч, түүнд тохирох бараануудыг productTable-ээс ялгаж гаргана
function filterProducts(params = {}) {
  return productTable.filter(product => {

    // 1. Ангиллын шүүлт
    if (params.category && product.category !== params.category) {
      return false;
    }

    // 2. Арьсны төрлийн шүүлт
    if (params.skinType && product.skinType !== params.skinType) {
      return false;
    }

    // 3. Доод үнийн шүүлт
    if (params.minPrice && product.price < Number(params.minPrice)) {
      return false;
    }

    // 4. Дээд үнийн шүүлт
    if (params.maxPrice && product.price > Number(params.maxPrice)) {
      return false;
    }

    // 5. Хайлтын шүүлт — нэр болон тайлбараар хайна
    if (params.q) {
      const query   = params.q.toLowerCase();
      const inName  = product.name.toLowerCase().includes(query);
      const inDesc  = product.description.toLowerCase().includes(query);
      if (!inName && !inDesc) return false;
    }

    return true;
  });
}

// Барааг үнээр нь (багаас их рүү), нэрээр нь (А-Я), эсвэл хамгийн их рейтингтэйгээр нь жагсаах үйлдлийг гүйцэтгэнэ
function sortProducts(products, sortBy = 'featured') {
  const sorted = [...products];

  switch (sortBy) {
    case 'price-low':
      sorted.sort((a, b) => a.price - b.price);
      break;

    case 'price-high':
      sorted.sort((a, b) => b.price - a.price);
      break;

    case 'rating':
      sorted.sort((a, b) => b.rating - a.rating);
      break;

    case 'name':
      sorted.sort((a, b) => a.name.localeCompare(b.name, 'mn'));
      break;

    default:
      // 'featured' — оруулсан дарааллаар (өөрчлөхгүй)
      break;
  }

  return sorted;
}

// Экспорт — бусад модулиас импортлон ашиглана
export { fetchProducts, filterProducts, sortProducts, Product };